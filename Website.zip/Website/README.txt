- Customer Website
  - Make Reservation
  - Register

- Staff Website
  - Take order
  - Crud


# Steps
1. Open Xampp and start Apache and MySQL
2. Copy all File in MiniProject (AdminPage, HomePage, StaffPage, index.php, Database) into Source Files
3. Run the project
4. DONE

# Example Accounts
## Customer
1. CustomerEmail: zixian@gmail.com
2. CustomerPassword: 123

## Staff
1. Staff Email: zixian@gmail.com
2. Password: 123

## Admin
1. Admin Email: zixian@gmail.com
2. Password: 123

