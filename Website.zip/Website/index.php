<?php
header("Location: HomePage/homepage.php");
exit();
?>